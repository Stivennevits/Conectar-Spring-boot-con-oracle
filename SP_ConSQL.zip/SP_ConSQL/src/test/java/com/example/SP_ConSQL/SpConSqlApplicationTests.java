package com.example.SP_ConSQL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpConSqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
