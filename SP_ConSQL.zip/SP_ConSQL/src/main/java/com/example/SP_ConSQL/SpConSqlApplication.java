package com.example.SP_ConSQL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpConSqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpConSqlApplication.class, args);
	}

}
